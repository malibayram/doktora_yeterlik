package dp.composite.solution1;

import java.util.Iterator;

public abstract class ManufacturingItem {
	private int machineID;
	private String name, factory;
	
	public ManufacturingItem(int machineID, String name, String factory) {
		this.machineID = machineID;
		this.name = name;
		this.factory = factory;
	}
	public int getMachineID() { return machineID; }
	public String getName( ) { return name; }
	public String getFactory() { return factory; }
	public void setFactory(String factory) { this.factory = factory; }
	public abstract int getParentID();
	public abstract void setParentID(int parentID);
	public abstract Iterator<ManufacturingItem> getParts( );
	public abstract boolean addPart( ManufacturingItem part );
	public abstract boolean removePart( ManufacturingItem part );
}
