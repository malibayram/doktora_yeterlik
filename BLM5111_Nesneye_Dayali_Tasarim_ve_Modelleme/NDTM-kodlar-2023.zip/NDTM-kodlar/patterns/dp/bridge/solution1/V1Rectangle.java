package dp.bridge.solution1;

public class V1Rectangle extends Rectangle {
	protected void drawLine(double x1, double y1, 
			double x2, double y2) {
		DP1.draw_a_line(x1,y1,x2,y2);
	}
}
