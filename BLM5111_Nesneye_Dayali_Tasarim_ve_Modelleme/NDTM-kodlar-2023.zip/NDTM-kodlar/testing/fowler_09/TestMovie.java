package fowler_09;

import junit.framework.TestCase;

public class TestMovie extends TestCase {
	
	public void testMovie( ) {
		Movie matrix = new Movie("The Matrix",Movie.REGULAR);
		Movie monster = new Movie("Monsters, Inc.",Movie.CHILDRENS);
		Movie surrogate = new Movie("Surrogates", Movie.NEW_RELEASE);
		assertTrue("Bunlar farkl� t�r filmlerdir", 
				matrix.getPriceCode() != monster.getPriceCode() );
		assertTrue("Bunlar farkl� t�r filmlerdir", 
				matrix.getPriceCode() != surrogate.getPriceCode() );
		assertFalse("Bunlar farkl� t�r filmlerdir", 
				monster.getPriceCode() == surrogate.getPriceCode() );
	}

}
