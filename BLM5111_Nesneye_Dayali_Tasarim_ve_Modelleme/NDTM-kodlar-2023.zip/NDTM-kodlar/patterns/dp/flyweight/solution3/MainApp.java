package dp.flyweight.solution3;

public class MainApp {
	public static void main(String[] args) {
		Karisim karaBarut = new Karisim();
		karaBarut.setIsim("Kara barut");
		karaBarut.bilesenEkle("NaNO3", 75);
		karaBarut.bilesenEkle("C", 15);
		karaBarut.bilesenEkle("S", 10);
		System.out.println( karaBarut.tarifEt() );
		Karisim temizBarut = new Karisim();
		temizBarut.setIsim("Temiz barut");
		temizBarut.bilesenEkle("KNO3", 75);
		temizBarut.bilesenEkle("C", 20);
		temizBarut.bilesenEkle("S", 25);
		System.out.println( temizBarut.tarifEt() );
	}

}
