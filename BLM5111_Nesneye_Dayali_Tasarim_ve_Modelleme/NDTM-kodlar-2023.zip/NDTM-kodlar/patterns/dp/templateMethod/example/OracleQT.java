package dp.templateMethod.example;

public class OracleQT extends QueryTemplate {
	String formatConnect(String DBname) {
		//Oracle'a g�re �zel bi�imlendirme komutlar�n� ver.
		return DBname;
	}
	String formatSelect(String querySpec) {
		//Oracle'a g�re �zel bi�imlendirme komutlar�n� ver.
		return querySpec;
	}
}
