package dp.flyweight.solution2;
import java.util.*;
public class Karisim {
	private String isim;
	private LinkedList<Bilesen> bilesenler = new LinkedList<Bilesen>();
	public String getIsim() { return isim; }
	public void setIsim(String isim) { this.isim = isim; }
	public void bilesenEkle( KimyasalMadde madde, double gram ) {
		bilesenler.add( new Bilesen(gram, madde) );
	}
	public String tarifEt( ) {
		String tarif = isim;
		for( Bilesen bilesen : bilesenler )
			tarif += "\n" + bilesen.getGram() + "gr " + bilesen.getMaddeAdi();
		return tarif;
	}
}
