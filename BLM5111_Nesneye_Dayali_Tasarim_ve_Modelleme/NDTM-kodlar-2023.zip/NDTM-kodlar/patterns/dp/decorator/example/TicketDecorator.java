package dp.decorator.example;

public abstract class TicketDecorator extends Component {
	private Component myComponent;
    public TicketDecorator (Component myComponent) {
        this.myComponent= myComponent;
    }
    public void prtTicket () {
        if (myComponent != null) myComponent.prtTicket();
    }

}
