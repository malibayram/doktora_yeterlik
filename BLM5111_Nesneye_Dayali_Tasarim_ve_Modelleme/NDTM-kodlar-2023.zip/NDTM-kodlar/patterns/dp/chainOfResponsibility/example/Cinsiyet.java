package dp.chainOfResponsibility.example;

public enum Cinsiyet { 
	KADIN("Kad�n"), ERKEK("Erkek"); 
	private String tanim;
	private Cinsiyet(String tanim) { this.tanim = tanim; }
	public String toString( ) { return tanim; }
}