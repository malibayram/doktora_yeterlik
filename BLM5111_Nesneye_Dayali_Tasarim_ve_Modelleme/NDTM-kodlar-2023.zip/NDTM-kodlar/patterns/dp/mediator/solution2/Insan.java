package dp.mediator.solution2;

public class Insan {
	private String adSoyad;
	private Araba araba;
	public Insan(String adSoyad) { this.adSoyad = adSoyad; }
	public String getAdSoyad() { return adSoyad; }
	void setAraba(Araba araba) { this.araba = araba; }
	public String toString( ) {
		String mesaj = "Ad Soyad: " + adSoyad;
		mesaj += ", Araba: " + araba.getPlaka();
		return mesaj;
	}

}
