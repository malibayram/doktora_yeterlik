package dp.abstractFactory.solution3;

public class OpenGLFactory extends ComponentFactory {
	public Renderer createRenderer() {
		return new OpenGLRenderer();
	}
	public Shader createShader() {
		return new OpenGLShader();
	}
}
