package dp.abstractFactory.solution2;

public class OpenGLRenderer extends Renderer {
	//do rendering in OpenGL
	public void renderOpA() { }
	public void renderOpB() { }
	public void renderOpC() { }
}
