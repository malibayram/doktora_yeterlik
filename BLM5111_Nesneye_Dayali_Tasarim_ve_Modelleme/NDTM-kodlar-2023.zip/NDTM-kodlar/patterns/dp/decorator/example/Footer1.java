package dp.decorator.example;

public class Footer1 extends TicketDecorator {
    public Footer1 (Component myComponent) {
        super(myComponent);
    }
    public void prtTicket() {
        super.prtTicket();
        // place printing footer 1 code here
        System.out.println(getClass().getName());
    }
}
