package dp.singleton.example;

public class TaskController {
	private TaxRule tax;

	public void setTax(TaxRule tax) {
		this.tax = tax;
	}
	
	public double taxAmount( double income ) {
		return tax.taxAmount( income );
	}

}
