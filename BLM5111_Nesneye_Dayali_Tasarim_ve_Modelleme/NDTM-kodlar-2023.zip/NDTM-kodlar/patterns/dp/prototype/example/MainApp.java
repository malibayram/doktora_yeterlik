package dp.prototype.example;

public class MainApp {

	public static void main(String[] args) {
		MonsterRegistry reg = new MonsterRegistry();
		reg.registerMonster( new GenericMonster(10, 10, 10, 10, 10) );
		Monster mySpecialMonster = reg.findMonster("Generic Monster").clone();
		mySpecialMonster.setHP(100);
		mySpecialMonster.setType("Bolum sonu canavar�");
		reg.registerMonster(mySpecialMonster);
	}

}
