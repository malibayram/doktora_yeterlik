package dp.mediator.solution1;

public class Insan {
	private String adSoyad;
	private Araba araba;
	public Insan(String adSoyad) { this.adSoyad = adSoyad; }
	public String getAdSoyad() { return adSoyad; }
	public void setAraba(Araba araba) { 
		this.araba = araba;
		araba.setSahip(this);
	}
	public String toString( ) {
		String mesaj = "Ad Soyad: " + adSoyad;
		mesaj += ", Araba: " + araba.getPlaka();
		return mesaj;
	}

}
