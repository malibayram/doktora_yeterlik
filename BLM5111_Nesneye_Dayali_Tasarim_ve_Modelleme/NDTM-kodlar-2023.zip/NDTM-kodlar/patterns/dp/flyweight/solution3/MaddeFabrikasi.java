package dp.flyweight.solution3;
import java.util.*;
public class MaddeFabrikasi {
	private static HashMap<String, KimyasalMadde> maddeler = new HashMap<String, KimyasalMadde>();
	static {
		maddeler.put( "C", new KimyasalMadde("Karbon", "C", 12.0107) );
		maddeler.put( "S", new KimyasalMadde("K�k�rt", "S", 32.066) );
		maddeler.put( "KNO3", new KimyasalMadde("Potasyum Nitrat", "KNO3", 101.103) );
		maddeler.put( "NaNO3", new KimyasalMadde("Sodyum Nitrat", "NaNO3", 84.9947) );
	}
	public static KimyasalMadde maddeBul( String simge ) {
		return maddeler.get(simge);
	}
}
