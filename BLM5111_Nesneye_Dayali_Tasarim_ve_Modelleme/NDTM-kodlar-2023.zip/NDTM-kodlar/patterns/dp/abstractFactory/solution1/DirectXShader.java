package dp.abstractFactory.solution1;

public class DirectXShader {
	//do shading in DirectX
	public void shadeOpA() { }
	public void shadeOpB() { }
	public void shadeOpC() { }
}
