package dp.factoryMethod.example;

public abstract class Store {
	protected abstract Order createOrder( String type );
	public void makeOrder( String type ) {
		Order newOrder = createOrder( type );
		newOrder.prepare( );
		newOrder.orderFromSupplier( );
		newOrder.pack( );
		newOrder.sendToCustomer( );
	}
}
