package dp.chainOfResponsibility.example;

public class User {
	private Cinsiyet cinsiyet;
	private GelirDuzeyi duzey;
	private int yas;
	public User(Cinsiyet cinsiyet, GelirDuzeyi duzey, int yas) {
		this.cinsiyet = cinsiyet; this.duzey = duzey; this.yas = yas;
	}
	public Cinsiyet getCinsiyet() { return cinsiyet; }
	public GelirDuzeyi getDuzey() { return duzey; }
	public int getYas() { return yas; }
	public boolean yasDahilMi( int altSinir, int ustSinir ) {
		if( yas >= altSinir && yas <= ustSinir )
			return true;
		else	return false;
	}
	public String toString( ) {
		return cinsiyet+","+duzey+","+yas;
	}
}
