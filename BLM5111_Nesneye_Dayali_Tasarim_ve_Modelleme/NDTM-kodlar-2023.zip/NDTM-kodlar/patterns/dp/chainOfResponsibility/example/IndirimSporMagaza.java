package dp.chainOfResponsibility.example;
public class IndirimSporMagaza extends Reklam {

	public IndirimSporMagaza(Banner banner, Reklam sonraki) {
		super(banner, sonraki);
	}

	public void reklamGoster(User u) {
		//Gerekli komutlar
	}

	public boolean reklamUygunMu(User u) { return true; }

}
