package dp.visitor.solution2;


public class ProjectCostVisitor implements ProjectVisitor {
	private double cost = 0.0;

	public ProjectCostVisitor(Project project) {
		project.accept(this);
	}

	public void visitDependentTask(DependentTask p) {
		visitTask(p);
	}

	public void visitDeliverable(Deliverable p) {
		cost += p.getMaterialsCost()+p.getProductionCost();
	}

	public void visitTask(Task p) {
		for( ProjectItem item : p.getProjectItems() ) {
			item.accept(this);
		}
	}

	public void visitProject(Project p) {
		for( ProjectItem item : p.getProjectItems() ) {
			item.accept(this);
		}
	}

	public double getCost() {
		return cost;
	}

}
