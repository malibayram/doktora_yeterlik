package dp.visitor.solution2;


public class ProjectTimeVisitor implements ProjectVisitor {
	private double time = 0.0;

	public ProjectTimeVisitor(Project project) {
		project.accept(this);
	}

	public void visitDependentTask(DependentTask p) {
		visitTask(p);
	}

	public void visitDeliverable(Deliverable p) {
	}

	public void visitTask(Task p) {
		time += p.getTimeRequired();
		for( ProjectItem item : p.getProjectItems() ) {
			item.accept(this);
		}
	}

	public void visitProject(Project p) {
		for( ProjectItem item : p.getProjectItems() ) {
			item.accept(this);
		}
	}

	public double getTime() {
		return time;
	}

}
