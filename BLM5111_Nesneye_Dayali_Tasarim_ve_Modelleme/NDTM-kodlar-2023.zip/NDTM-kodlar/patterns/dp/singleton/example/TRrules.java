package dp.singleton.example;

public class TRrules implements TaxRule {
	private static TRrules instance;

	private TRrules( ) {
		//gerekli ilklendirmeler
	}
	
	public static TRrules getInstance() {
		if( instance == null )
			instance = new TRrules( );
		return instance;
	}

	public double taxAmount(double income) {
		return income * 0.18;
	}

}
