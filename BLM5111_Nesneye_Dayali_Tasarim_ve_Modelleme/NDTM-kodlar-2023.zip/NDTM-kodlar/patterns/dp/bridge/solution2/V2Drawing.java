package dp.bridge.solution2;

public class V2Drawing extends Drawing {

	public void drawCircle(double x, double y, double r) {
		DP2.drawcircle(x,y,r);
	}

	public void drawLine(double x1, double y1, 
			double x2, double y2) {
		DP2.drawline(x1,x2,y1,y2);
	}

}
