package dp.flyweight.solution1c;
import java.util.*;
public class Karisim {
	private String isim;
	private LinkedList<KimyasalMadde> maddeler = new LinkedList<KimyasalMadde>();
	public String getIsim() { return isim; }
	public void setIsim(String isim) { this.isim = isim; }
	public void maddeEkle( KimyasalMadde madde, double gram ) {
		madde.setGram(gram);
		maddeler.add( madde );
	}
	public String tarifEt( ) {
		String tarif = isim;
		for( KimyasalMadde madde : maddeler )
			tarif += "\n" + madde.getGram() + "gr " + madde.getIsim();
		return tarif;
	}
}
