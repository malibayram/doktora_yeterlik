package dp.visitor.solution2;

public class Contact { //STUB

}
