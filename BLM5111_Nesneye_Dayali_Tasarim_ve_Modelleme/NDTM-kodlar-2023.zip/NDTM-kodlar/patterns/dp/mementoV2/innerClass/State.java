package dp.mementoV2.innerClass;

public class State implements Cloneable {
	private String durum;

	public String getDurum() {
		return durum;
	}

	void setDurum(String durum) {
		this.durum = durum;
	}
	
	public State clone() {
		State s = new State();
		s.durum = new String(durum);
		return s;
	}
	
}
