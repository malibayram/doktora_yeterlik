package dp.abstractFactory.solution2;

public class OpenGLShader extends Shader {
	//do shading in OpenGL
	public void shadeOpA() { }
	public void shadeOpB() { }
	public void shadeOpC() { }
}
