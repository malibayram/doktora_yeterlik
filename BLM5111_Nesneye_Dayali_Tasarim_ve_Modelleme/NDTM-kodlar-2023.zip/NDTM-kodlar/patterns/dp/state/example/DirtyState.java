package dp.state.example;
public class DirtyState extends State { }
