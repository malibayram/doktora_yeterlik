package dp.flyweight.solution3;

public class KimyasalMadde {
	private String isim; 
	private String simge;
	private double atomAgirligi;
	
	public KimyasalMadde(String isim, String simge, double atomAgirligi) {
		this.isim = isim; this.simge = simge;
		this.atomAgirligi = atomAgirligi;
	}
	public String getIsim() { return isim; }
	public String getSimge() { return simge; }
	public double getAtomAgirligi() { return atomAgirligi; }
	public double getMol( double gram ) {
		return gram/atomAgirligi;
	}
	
}
