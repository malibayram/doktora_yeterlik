package dp.mementoV2.innerClass;

import dp.mementoV2.innerClass.Originator.Memento;

public class Caretaker {
	public void test( ) {
	      Originator subject = new Originator( );
	      subject.modify("ilk durum");
	      Memento mem = subject.createMemento( );
	      subject.modify("yeni durum");
	      //bir s�re sonra...
	      subject.setMemento( mem );
	      System.out.println(subject);
	   }

	public static void main( String[] args ) {
		Caretaker ct = new Caretaker();
		ct.test();
		//System.out.println("K�rma denemesi: ");
		//ct.testBroken();
	}

	public void testBroken( ) {
	      Originator subject = new Originator( );
	      subject.modify("ilk durum");
	      subject.modify("yeni durum");
	      //bir s�re sonra...
	      Originator fakeSubject = new Originator( );
	      fakeSubject.modify("sahte durum");
	      Memento memFake = fakeSubject.createMemento();
	      subject.setMemento( memFake );
	      System.out.println(subject);
	   }

}
