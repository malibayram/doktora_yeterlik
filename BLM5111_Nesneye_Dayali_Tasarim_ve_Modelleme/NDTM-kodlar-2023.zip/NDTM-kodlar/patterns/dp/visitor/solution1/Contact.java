package dp.visitor.solution1;

public class Contact { //STUB

}
