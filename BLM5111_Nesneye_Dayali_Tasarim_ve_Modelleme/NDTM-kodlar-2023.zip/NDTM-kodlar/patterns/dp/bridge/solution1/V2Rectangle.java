package dp.bridge.solution1;

public class V2Rectangle extends Rectangle {
	protected void drawLine(double x1, double y1, 
			double x2, double y2) {
		DP2.drawline(x1,x2,y1,y2);
	}
}
