package dp.abstractFactory.solution2;

public abstract class Renderer {
	public abstract void renderOpA();
	public abstract void renderOpB();
	public abstract void renderOpC();
}
