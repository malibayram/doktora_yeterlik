package dp.abstractFactory.solution2;

public enum LibraryType {
	OpenGL, DirectX; 
}
