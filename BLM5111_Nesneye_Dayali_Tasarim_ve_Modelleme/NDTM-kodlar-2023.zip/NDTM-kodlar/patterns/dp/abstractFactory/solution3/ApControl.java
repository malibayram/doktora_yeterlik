package dp.abstractFactory.solution3;

public class ApControl {
	private ComponentFactory library;
	private Renderer r; 
	private Shader s;
	public ApControl( ComponentFactory library ) {
		this.library = library;
		/* Se�enek A: library nesnesini ilklendirerek k�t�phane t�r�n� 
		 * switch-case ile �nceki �rnekteki gibi belirle 
		 * Se�enek B: buradaki gibi kurucu metoda parametre olarak ver.
		 * Se�enek C: Farkl� t�r hedef bilgisayarlar i�in
		 * farkl� da��t�mlar yap ve alttaki uygun sat�r�n yorumunu kald�r.
		// library = new OpenGLFactory();
		// library = new DirectXFactory();
		*/
		r = this.library.createRenderer();
		s = this.library.createShader();
	}
	void doRendering ( ) {
		r.renderOpA();
		r.renderOpB();
		r.renderOpC();
	}
	void doShading ( ) { 
		s.shadeOpA();
		s.shadeOpB();
		s.shadeOpC();
	}
}
