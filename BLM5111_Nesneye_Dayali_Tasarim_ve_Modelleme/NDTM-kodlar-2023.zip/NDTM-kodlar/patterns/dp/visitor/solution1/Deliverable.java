package dp.visitor.solution1;

public class Deliverable extends ProjectItem{
	private Contact owner;
	private double materialsCost;
	private double productionCost;

	public Deliverable(String newName, String newDescription,
			Contact newOwner, double newMaterialsCost, double newProductionCost){
		super(newName, newDescription);
		owner = newOwner;
		materialsCost = newMaterialsCost;
		productionCost = newProductionCost;
	}

	public Contact getOwner(){ return owner; }
	public double getMaterialsCost(){ return materialsCost; }
	public double getProductionCost(){ return productionCost; }

	public void setMaterialsCost(double newCost){ materialsCost = newCost; }
	public void setProductionCost(double newCost){ productionCost = newCost; }
	public void setOwner(Contact newOwner){ owner = newOwner; }
}
