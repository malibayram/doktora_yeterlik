package dp.singleton.example;

public interface TaxRule {
	public double taxAmount( double income );
}
