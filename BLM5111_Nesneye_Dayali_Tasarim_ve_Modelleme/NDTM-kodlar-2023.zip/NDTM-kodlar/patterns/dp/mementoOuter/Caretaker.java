package dp.mementoOuter;

import dp.memento.*;

public class Caretaker {
	public void test( ) {
		Originator subject = new Originator( );
		subject.modify("ilk durum");
		Memento mem = subject.createMemento( );
		subject.modify("yeni durum");
		//bir s�re sonra...
		subject.setMemento( mem );
		
		System.out.println(subject);
	}
	
	public static void main( String[] args ) {
		Caretaker ct = new Caretaker();
		ct.test();
	}

}
