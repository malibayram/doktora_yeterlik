package dp.mediator.example;

public interface Mediator {
	public boolean addPartToMachine( Machine main, MachinePart part );
	public boolean removePartFromMachine( Machine main, MachinePart part );
}
