package dp.observer.example;

public interface ICObserver {
	public void update (Customer myCust);
}
