package dp.state.example;
import java.io.*;
public class CleanState extends State {
	public void edit( ){
		PIMApplication.setCurrentState(PIMApplication.DIRTY);
		super.edit();
	}
	public void save(File f, Serializable s) throws IOException {
		super.save(f, s);
		PIMApplication.setCurrentState(PIMApplication.CLEAN);
	}
}
