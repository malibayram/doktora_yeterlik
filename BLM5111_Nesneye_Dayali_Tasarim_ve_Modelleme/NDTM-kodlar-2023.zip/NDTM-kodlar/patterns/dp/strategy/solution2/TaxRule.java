package dp.strategy.solution2;

public interface TaxRule {
	public double taxAmount( double income );
}
