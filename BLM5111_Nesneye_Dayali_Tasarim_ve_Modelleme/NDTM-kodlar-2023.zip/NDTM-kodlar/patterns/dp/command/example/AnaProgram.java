package dp.command.example;
public class AnaProgram {
	Kumanda kumanda;
	public AnaProgram( ) {
		kumanda = new Kumanda();
		kumanda.dugmeEkle( new AydinlatmaDugmesi( "Antre" ) );
		kumanda.dugmeEkle( new AydinlatmaDugmesi( "Salon" ) );
		kumanda.dugmeEkle( new AydinlatmaDugmesi( "Mutfak" ) );
		kumanda.dugmeEkle( new AydinlatmaDugmesi( "Oda" ) );
		kumanda.dugmeEkle( new ElektronikAlet( "Vestel TV" ) );
		kumanda.dugmeEkle( new Iklimlendirme( "Kombi" ) );
	}
	public void evBoskenSokakKapisiAcildi( ) {
		kumanda.ac(0);
		kumanda.ac(5);
	}
	public void evdeKimseKalmadi( ) {
		kumanda.hepsiniKapa( );
	}
	public static void main(String[] args) {
		AnaProgram prg = new AnaProgram();
		prg.evBoskenSokakKapisiAcildi();
		System.out.println("Evden ��k�l�yor");
		prg.evdeKimseKalmadi();
	}
}
