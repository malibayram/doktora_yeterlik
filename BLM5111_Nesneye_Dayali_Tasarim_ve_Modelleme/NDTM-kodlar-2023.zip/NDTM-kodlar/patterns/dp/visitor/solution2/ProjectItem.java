package dp.visitor.solution2;
public abstract class ProjectItem {
	private String name;
	private String description;

	public ProjectItem(String newName, String newDescription){
		name = newName;
		description = newDescription;
	}
	public String getName(){ return name; }
	public String getDescription(){ return description; }
	public void setName(String newName){ name = newName; }
	public void setDescription(String newDescription){ description = newDescription; }

	abstract public void accept(ProjectVisitor v);
}