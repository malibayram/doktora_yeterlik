package dp.bridge.solution3;

public abstract class Shape {
	public abstract void draw( );
	private Drawing _dp;
	public Shape (Drawing dp) { _dp= dp; }
	public final void drawLine(double x1, double y1, 
			double x2, double y2) { _dp.drawLine(x1, y1, x2, y2); }
	public final void drawCircle(double x,double y,
			double r ) {_dp.drawCircle(x, y, r); }
}
