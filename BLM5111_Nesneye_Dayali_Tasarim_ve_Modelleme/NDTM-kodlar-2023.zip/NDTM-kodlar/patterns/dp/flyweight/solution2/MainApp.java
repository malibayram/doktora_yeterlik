package dp.flyweight.solution2;

public class MainApp {
	public static void main(String[] args) {
		Karisim karaBarut = new Karisim();
		karaBarut.setIsim("Kara barut");
		karaBarut.bilesenEkle( new KimyasalMadde("Sodyum Nitrat", "NaNO3", 84.9947 ), 75 );
		karaBarut.bilesenEkle( new KimyasalMadde("Karbon", "C", 12.0107), 15);
		karaBarut.bilesenEkle( new KimyasalMadde("K�k�rt", "S", 32.066), 10);
		System.out.println( karaBarut.tarifEt() );
	}

}
