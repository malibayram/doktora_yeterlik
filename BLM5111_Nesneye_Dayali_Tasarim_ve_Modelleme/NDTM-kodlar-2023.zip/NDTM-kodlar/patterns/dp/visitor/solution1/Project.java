package dp.visitor.solution1;

import java.util.ArrayList;
public class Project extends ProjectItem{
	private ArrayList<ProjectItem> projectItems = new ArrayList<>();

	public Project(String newName, String newDescription){
		super(newName, newDescription);
	}

	public ArrayList<ProjectItem> getProjectItems(){ return projectItems; }

	public void addProjectItem(ProjectItem element){
		if (!projectItems.contains(element)){
			projectItems.add(element);
		}
	}
	public void removeProjectItem(ProjectItem element){
		projectItems.remove(element);
	}

}
