package dp.prototype.example;

public abstract class Monster {
	protected int HP, DEX, AGL, LUCK, CHR;
	protected String type;

	public abstract Monster clone( );
	
	protected Monster(int hp, int dex, int agl, int luck, int chr) {
		HP = hp; DEX = dex; AGL = agl; LUCK = luck; CHR = chr;
	}

	public String getType() {
		return type;
	}

	public int getHP() {
		return HP;
	}

	protected void setHP(int hP) {
		HP = hP;
	}
	
	public int getDEX() {
		return DEX;
	}

	protected void setDEX(int dEX) {
		DEX = dEX;
	}

	public int getAGL() {
		return AGL;
	}

	protected void setAGL(int aGL) {
		AGL = aGL;
	}

	public int getLUCK() {
		return LUCK;
	}

	protected void setLUCK(int lUCK) {
		LUCK = lUCK;
	}

	public int getCHR() {
		return CHR;
	}

	protected void setCHR(int cHR) {
		CHR = cHR;
	}

	protected void setType(String type) {
		this.type = type;
	}
		
}
