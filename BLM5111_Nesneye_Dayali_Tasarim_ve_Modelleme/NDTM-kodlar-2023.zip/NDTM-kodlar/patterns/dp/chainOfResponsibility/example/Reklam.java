package dp.chainOfResponsibility.example;

@SuppressWarnings("unused")
public abstract class Reklam {
	private Banner banner;
	private Reklam sonraki;
	public Reklam(Banner banner, Reklam sonraki) { 
		this.banner = banner; this.sonraki = sonraki; 
	}
	public abstract boolean reklamUygunMu ( User u );
	public abstract void reklamGoster( User u );
	public final void reklamKotar( User u ) {
		if( reklamUygunMu(u) ) {
			System.out.println( this.getClass().getName()
					+ "->" + u );
			reklamGoster(u);
		}
		else if( sonraki != null ) {
			System.out.println( this.getClass().getName()
					+ "->" + sonraki.getClass().getName());
			sonraki.reklamKotar(u);
		}
		
	}
}
