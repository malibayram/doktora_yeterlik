package dp.command.example;
public class AydinlatmaDugmesi implements AcKapa {
	private String isim;
	public AydinlatmaDugmesi(String isim) { this.isim = isim; }
	public String toString( ) { return "AcKapa:" + isim; }
	public boolean ac() {
		System.out.println("ACIK: " + this);
		return true; }
	public boolean kapa() { 
		System.out.println("KAPALI: " + this);
		return true; }
}
