package dp.decorator.example;

public class Footer2 extends TicketDecorator {
    public Footer2 (Component myComponent) {
        super(myComponent);
    }
    public void prtTicket() {
        super.prtTicket();
        // place printing footer 2 code here
        System.out.println(getClass().getName());
   }
}
