package dp.iterator.example;

public class MainProgram {

	public static void main(String[] args) {
		Waitress w = new Waitress(new PancakeHouseMenu(), new DinerMenu());
		//WaitressQuickAndDirty w = new WaitressQuickAndDirty( );
		w.printMenu();
		w.printVegetarianMenu();
	}

}
