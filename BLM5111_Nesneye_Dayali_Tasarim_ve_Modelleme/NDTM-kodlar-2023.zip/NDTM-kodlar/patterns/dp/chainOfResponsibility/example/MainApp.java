package dp.chainOfResponsibility.example;

public class MainApp {
	private User[] users;
	
	public MainApp( ) {
		users = new User[3];
		users[0] = new User( Cinsiyet.ERKEK, GelirDuzeyi.C, 23 );
		users[1] = new User( Cinsiyet.ERKEK, GelirDuzeyi.A, 53 );
		users[2] = new User( Cinsiyet.KADIN, GelirDuzeyi.B, 33 );
	}

	public void kampanya1( ) {
		Reklam[] reklamlar = new Reklam[3];
		reklamlar[2] = new IndirimSporMagaza(new Banner(), null);
		reklamlar[1] = new FitnessSalonu(new Banner(), reklamlar[2]);
		reklamlar[0] = new TrasBicak(new Banner(), reklamlar[1]);
		reklamlar[0].reklamKotar(users[0]);
		reklamlar[0].reklamKotar(users[1]);
		reklamlar[0].reklamKotar(users[2]);
	}

	public void kampanya2( ) {
		Reklam[] reklamlar = new Reklam[4];
		reklamlar[3] = new IndirimSporMagaza(new Banner(), null);
		reklamlar[2] = new FitnessSalonu(new Banner(), reklamlar[3]);
		reklamlar[1] = new TrasBicak(new Banner(), reklamlar[2]);
		reklamlar[0] = new OtoDergi(new Banner(), reklamlar[1]);
		reklamlar[0].reklamKotar(users[0]);
		reklamlar[0].reklamKotar(users[1]);
		reklamlar[0].reklamKotar(users[2]);
	}

	public static void main(String[] args) {
		MainApp app = new MainApp();
		app.kampanya1();
		//app.kampanya2();
	}
	
}
