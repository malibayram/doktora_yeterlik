package dp.abstractFactory.solution3;

public abstract class Shader {
	public void shadeOpA() { }
	public void shadeOpB() { }
	public void shadeOpC() { }
}
