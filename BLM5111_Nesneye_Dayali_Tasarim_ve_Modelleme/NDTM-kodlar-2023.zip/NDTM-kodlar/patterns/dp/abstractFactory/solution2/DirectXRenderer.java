package dp.abstractFactory.solution2;

public class DirectXRenderer extends Renderer {
	//do rendering in DirectX
	public void renderOpA() { }
	public void renderOpB() { }
	public void renderOpC() { }
}
