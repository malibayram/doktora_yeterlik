package dp.command.example;
import java.util.*;
public class Kumanda {
	private ArrayList<AcKapa> acKapaDugmeleri;
	public Kumanda( ) {
		acKapaDugmeleri = new ArrayList<AcKapa>();
	}
	public void dugmeEkle( AcKapa dugme ) {
		acKapaDugmeleri.add(dugme);
	}
	public boolean ac( int dugmeNo ) {
		if( acKapaDugmeleri.get(dugmeNo) == null )
			return false;
		return acKapaDugmeleri.get(dugmeNo).ac();
	}
	public boolean kapa( int dugmeNo ) {
		if( acKapaDugmeleri.get(dugmeNo) == null )
			return false;
		return acKapaDugmeleri.get(dugmeNo).kapa();
	}
	public void hepsiniKapa( ) {
		for( AcKapa dugme : acKapaDugmeleri )
			dugme.kapa();
	}
}
