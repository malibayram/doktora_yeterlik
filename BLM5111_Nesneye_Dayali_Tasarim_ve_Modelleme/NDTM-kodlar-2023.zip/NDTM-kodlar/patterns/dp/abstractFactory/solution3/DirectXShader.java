package dp.abstractFactory.solution3;

public class DirectXShader extends Shader {
	//do shading in DirectX
	public void shadeOpA() { }
	public void shadeOpB() { }
	public void shadeOpC() { }
}
