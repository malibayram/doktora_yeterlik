package dp.singleton.example;

public final class EUrules implements TaxRule {
	private static EUrules instance;
	
	public static EUrules getInstance() {
		if( instance == null )
			instance = new EUrules( );
		return instance;
	}

	private EUrules( ) {
		//gerekli ilklendirmeler
	}
	
	public double taxAmount(double income) {
		return income * 0.15;
	}

}
