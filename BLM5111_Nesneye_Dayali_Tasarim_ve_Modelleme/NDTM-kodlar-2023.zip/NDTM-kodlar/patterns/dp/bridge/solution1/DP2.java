package dp.bridge.solution1;

public class DP2 {
	static void drawline( double x1, double x2, 
		double y1, double y2 ) {
		//�izimi yap
	}
}
