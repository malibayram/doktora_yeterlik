package dp.abstractFactory.solution3;

public enum LibraryType {
	OpenGL, DirectX; 
}
