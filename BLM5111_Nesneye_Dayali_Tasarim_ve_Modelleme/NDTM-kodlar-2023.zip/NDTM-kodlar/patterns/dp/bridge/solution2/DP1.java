package dp.bridge.solution2;

public class DP1 {
	public static void draw_a_line( double x1, double y1, 
			double x2, double y2 ) {
		//�izimi yap
	}
	public static void draw_a_circle( double x,
			double y, double r ) {
		//�izimi yap
	}
}
