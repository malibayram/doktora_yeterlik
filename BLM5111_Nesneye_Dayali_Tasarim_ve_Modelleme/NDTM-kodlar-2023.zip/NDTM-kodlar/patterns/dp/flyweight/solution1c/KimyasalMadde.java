package dp.flyweight.solution1c;

public class KimyasalMadde {
	private double gram;
	private String isim; 
	private String simge;
	private double atomAgirligi;
	
	public KimyasalMadde(String isim, String simge, double atomAgirligi) {
		this.isim = isim; this.simge = simge;
		this.atomAgirligi = atomAgirligi;
	}
	public double getGram() { return gram; }
	public void setGram(double gram) { this.gram = gram; }
	public String getIsim() { return isim; }
	public String getSimge() { return simge; }
	public double getAtomAgirligi() { return atomAgirligi; }
	public double getMol( double gram ) {
		return gram/atomAgirligi;
	}
	
}
