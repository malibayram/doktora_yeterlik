package dp.state.example;
import java.util.*;
import java.io.*;
public class PIMApplication {
	public static final State CLEAN = new CleanState();
	public static final State DIRTY = new DirtyState();
	private static State currentState = CLEAN;
	private LinkedList<Record> records = new LinkedList<Record>(); //burdan devam edebilirsin.

	public static State getCurrentState(){
		return currentState;
	}
	 public static void setCurrentState(State state){
		 currentState = state;
	 }
	 public void editARecord( ) {
		 currentState.edit();
	 }
	 public void saveRecords( java.io.File f, Serializable s ) throws IOException {
		 currentState.save(f, s);
	 }
}
