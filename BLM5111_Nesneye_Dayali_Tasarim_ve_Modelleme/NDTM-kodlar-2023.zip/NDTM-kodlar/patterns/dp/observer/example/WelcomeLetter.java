package dp.observer.example;

public class WelcomeLetter implements ICObserver {
	public void update(Customer myCust) {
		@SuppressWarnings("unused")
		String state = myCust.getState( );
		// TODO Gerekli i�lemleri tamamla
	}
}
