package dp.mediator.example;

public class MediatorImpl implements Mediator {

	public boolean addPartToMachine(Machine main, MachinePart part) {
		if( main.getMachineID() == part.getParentID() )
			return main.addPart(part);
		else {
			MachinePart newPart = part.clone(main.getMachineID());
			return main.addPart(newPart);
		}
	}

	public boolean removePartFromMachine(Machine main, MachinePart part) {
		if( main.getMachineID() == part.getParentID() )
			return main.removePart(part);
		return false;
	}

}
