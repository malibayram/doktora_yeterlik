package dp.iterator.example;
import java.util.*;
public class Waitress {
	private Menu pancakeHouseMenu, dinerMenu;
 
	public Waitress(Menu pancakeHouseMenu, Menu dinerMenu) {
		this.pancakeHouseMenu = pancakeHouseMenu;
		this.dinerMenu = dinerMenu;
	}
 
	public void printMenu() {
		Iterator<MenuItem> pancakeIterator = pancakeHouseMenu.createIterator();
		System.out.println("MENU\n----\nBREAKFAST");
		printMenu(pancakeIterator);
		Iterator<MenuItem> dinerIterator = dinerMenu.createIterator();
		System.out.println("\nLUNCH");
		printMenu(dinerIterator);
	}
 
	private void printMenu(Iterator<MenuItem> iterator) {
		while (iterator.hasNext()) {
			MenuItem menuItem = iterator.next();
			printMenuItem(menuItem);
		}
	}
	private void printMenuItem( MenuItem menuItem ) {
		System.out.print(menuItem.getName() + ", ");
		System.out.print(menuItem.getPrice() + " -- ");
		System.out.println(menuItem.getDescription());
	}
	public void printVegetarianMenu() {
		System.out.println("\nVEGETARIAN MENU\n----\nBREAKFAST");
		printVegetarianMenu(pancakeHouseMenu.createIterator());
		System.out.println("\nLUNCH");
		printVegetarianMenu(dinerMenu.createIterator());
	}
	private void printVegetarianMenu(Iterator<MenuItem> iterator) {
		while (iterator.hasNext()) {
			MenuItem menuItem = iterator.next();
			if (menuItem.isVegetarian()) {
				printMenuItem(menuItem);
			}
		}
	}

	public void printBreakfastMenu() {
		Iterator<MenuItem> pancakeIterator = pancakeHouseMenu.createIterator();
		System.out.println("MENU\n----\nBREAKFAST");
		printMenu(pancakeIterator);
	}

	public void printDinerMenu() {
		Iterator<MenuItem> dinerIterator = dinerMenu.createIterator();
		System.out.println("MENU\n----\nLUNCH");
		printMenu(dinerIterator);
	}

	public static void main( String args[] ) {
		Waitress yes = new Waitress(new PancakeHouseMenu(), new DinerMenu());
		yes.printMenu();
	}

}
