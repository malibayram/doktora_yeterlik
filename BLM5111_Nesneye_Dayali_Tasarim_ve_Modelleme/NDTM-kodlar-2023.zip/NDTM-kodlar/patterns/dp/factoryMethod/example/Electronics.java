package dp.factoryMethod.example;

public class Electronics extends Order {
	@SuppressWarnings("unused")
	private String barcode;

	public Electronics( String barcode ) {
		super( );
		this.barcode = barcode;
	}

	@Override
	public void orderFromSupplier() {
		//Elektronik malzeme i�in yap�lacak i�lemlerin tan�mlanmas�
	}

	@Override
	public void pack() {
		//Elektronik malzeme i�in yap�lacak i�lemlerin tan�mlanmas�
	}

	@Override
	public void prepare() {
		//Elektronik malzeme i�in yap�lacak i�lemlerin tan�mlanmas�
	}

	@Override
	public void sendToCustomer() {
		//Elektronik malzeme i�in yap�lacak i�lemlerin tan�mlanmas�
	}

}
