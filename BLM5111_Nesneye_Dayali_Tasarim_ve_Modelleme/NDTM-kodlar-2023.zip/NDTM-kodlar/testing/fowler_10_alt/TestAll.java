package fowler_10_alt;

import junit.framework.*;

public class TestAll {
	public static Test suite( ) {
		TestSuite suite = new TestSuite("B�t�n testler");
		suite.addTestSuite(TestCustomer.class);
		suite.addTestSuite(TestMovie.class);
		return suite;
	}
	

}
