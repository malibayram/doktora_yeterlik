package dp.visitor.solution2;

public class Report {
	private Project project;
	public Report() {
		project = new Project("Y�ksek Lisans", "Lisans�st� e�itim (Y�ksek lisans)");
		Task gorev; Deliverable urun;
		gorev = new Task("2014-1 dersleri","2014-2015 G�z yar�y�l� (4 ders)",null,15);
		urun = new Deliverable("BLM 5128", "Yaz�l�m Kalitesi ve Test Teknikleri", null, 45, 30);
		gorev.addProjectItem(urun);
		urun = new Deliverable("BLM 5130", "Nesneye Dayal� Tasar�m ve Modelleme", null, 45, 40);
		gorev.addProjectItem(urun);
		urun = new Deliverable("BLM 5116", "�leri Algoritma Analizi ve Tasar�m�", null, 45, 35);
		gorev.addProjectItem(urun);
		urun = new Deliverable("BLM 5140", "Veri Madencili�i ve Bilgi Ke�fi", null, 45, 40);
		gorev.addProjectItem(urun);
		project.addProjectItem(gorev);
		gorev = new Task("2014-2 dersleri","2014-2015 Bahar yar�y�l� (4 ders)",null,15);
		urun = new Deliverable("BLM 5126", "�leri Programlama Dilleri", null, 45, 30);
		gorev.addProjectItem(urun);
		urun = new Deliverable("BLM 5143", "Veri Taban� Sistemlerinin Ger�eklenmesi", null, 45, 40);
		gorev.addProjectItem(urun);
		urun = new Deliverable("BLM 5139", "�ok De�i�kenli Veri Analizi", null, 45, 35);
		gorev.addProjectItem(urun);
		urun = new Deliverable("BLM 5188", "Seminer", null, 45, 30);
		gorev.addProjectItem(urun);
		project.addProjectItem(gorev);
		gorev = new Task("BLM 5198","2015-2016 Y�ksek lisans tezi",null,30);
		urun = new Deliverable("Tez metni", "Bez ciltli tez", null, 90, 270);
		gorev.addProjectItem(urun);
		urun = new Deliverable("Bildiri", "Ulusal veya uluslararas� bildiri veya makale", null, 4, 170);
		gorev.addProjectItem(urun);
		project.addProjectItem(gorev);
	}

	public static void main(String[] args) {
		Report rep = new Report();
		ProjectCostVisitor vc = new ProjectCostVisitor(rep.project);
		System.out.println("Proje ad� ve a��klamas�: " + rep.project.getName() + ": " + rep.project.getDescription());
		System.out.println("Proje maliyeti: " + vc.getCost() + " saat �al��ma.");
		ProjectTimeVisitor vt = new ProjectTimeVisitor(rep.project);
		System.out.println("Proje s�resi: " + vt.getTime() + " hafta.");
	}

}
