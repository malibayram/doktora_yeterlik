package dp.abstractFactory.solution2;

public abstract class Shader {
	public abstract void shadeOpA();
	public abstract void shadeOpB();
	public abstract void shadeOpC();
}
