package dp.flyweight.solution1b;

public class MainApp {
	public static void main(String[] args) {
		Karisim karaBarut = new Karisim();
		KimyasalMadde c = new KimyasalMadde("Karbon", "C", 12.0107);
		karaBarut.setIsim("Kara barut");
		KimyasalMadde bilesen = new KimyasalMadde("Sodyum Nitrat","NaNO3", 84.9947);
		bilesen.setGram(75); karaBarut.maddeEkle( bilesen );
		c.setGram(15); karaBarut.maddeEkle( c );
		bilesen = new KimyasalMadde("K�k�rt", "S", 32.066);
		bilesen.setGram(10); karaBarut.maddeEkle( bilesen );
		System.out.println( karaBarut.tarifEt() );
		System.out.println("c.gr="+c.getGram());

		Karisim temizBarut = new Karisim();
		temizBarut.setIsim("Temiz barut");
		bilesen = new KimyasalMadde("Potasyum Nitrat","KNO3", 84.9947);
		bilesen.setGram(75); temizBarut.maddeEkle( bilesen );
		c.setGram(14); temizBarut.maddeEkle( c );
		bilesen = new KimyasalMadde("K�k�rt", "S", 32.066);
		bilesen.setGram(10); temizBarut.maddeEkle( bilesen );
		System.out.println( temizBarut.tarifEt() );
		System.out.println("c.gr="+c.getGram());
		
		
}

}
