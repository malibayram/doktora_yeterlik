package dp.flyweight.solution1a;

public class MainApp {
	public static void main(String[] args) {
		Karisim karaBarut = new Karisim();
		karaBarut.setIsim("Kara barut");
		KimyasalMadde bilesen = new KimyasalMadde("Sodyum Nitrat","NaNO3", 84.9947);
		bilesen.setGram(75); karaBarut.maddeEkle( bilesen );
		bilesen = new KimyasalMadde("Karbon", "C", 12.0107);
		bilesen.setGram(15); karaBarut.maddeEkle( bilesen );
		bilesen = new KimyasalMadde("K�k�rt", "S", 32.066);
		bilesen.setGram(10); karaBarut.maddeEkle( bilesen );
		System.out.println( karaBarut.tarifEt() );

		Karisim temizBarut = new Karisim();
		karaBarut.setIsim("Temiz barut");
		bilesen = new KimyasalMadde("Potasyum Nitrat","KNO3", 84.9947);
		bilesen.setGram(75); temizBarut.maddeEkle( bilesen );
		bilesen = new KimyasalMadde("Karbon", "C", 12.0107);
		bilesen.setGram(14); temizBarut.maddeEkle( bilesen );
		bilesen = new KimyasalMadde("K�k�rt", "S", 32.066);
		bilesen.setGram(10); temizBarut.maddeEkle( bilesen );
		System.out.println( temizBarut.tarifEt() );
		
		
}

}
