package dp.mediator.solution2;
//bu mediator kal�b�n�n s�n�f �emas�na tam uymad�. 
public class Mediator {
	public final void iliskiKur( Insan birInsan, Araba birAraba ) {
		birInsan.setAraba(birAraba);
		birAraba.setSahip(birInsan);
	}
}
