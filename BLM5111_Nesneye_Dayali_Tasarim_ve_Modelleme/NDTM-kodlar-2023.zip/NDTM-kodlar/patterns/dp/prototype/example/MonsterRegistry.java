package dp.prototype.example;
import java.util.*;
public class MonsterRegistry {
	private HashMap<String, Monster> monsters;
	
	public MonsterRegistry() {
		monsters = new HashMap<String, Monster>();
	}
	
	public Monster findMonster( String type ) {
		return monsters.get( type );
	}
	
	public void registerMonster( Monster m ) {
		monsters.put( m.getType(), m );
	}

}
