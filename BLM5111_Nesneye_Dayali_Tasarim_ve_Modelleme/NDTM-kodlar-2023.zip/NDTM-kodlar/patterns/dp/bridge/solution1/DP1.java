package dp.bridge.solution1;

public class DP1 {
	static void draw_a_line( double x1, double y1, 
		double x2, double y2 ) {
		//�izimi yap
	}
}
